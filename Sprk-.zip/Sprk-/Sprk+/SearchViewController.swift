//
//  SearchViewController.swift
//  Sprk+
//
//  Created by 姚逸飞 on 7/17/19.
//  Copyright © 2019 Carlo Saraniti. All rights reserved.
//


import UIKit
import CDYelpFusionKit
import CoreLocation

//class ResultCellController: UITableViewController {
//    override func viewDidLoad() {
//        super.viewDidLoad()
//    }
//
//    override func numberOfSections(in tableView: UITableView) -> Int {
//        return 1
//    }
//
//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return resultArray.count
//    }
//
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "ResultDisplayPrototypeCell", for: indexPath) as? ResultDisplayCell
//        let content = resultArray[indexPath.row]
//        cell?.titleForName.text = content["name"] as! String
//        cell?.titleForCategory.text = content["category"] as! String
//        let url = URL(string: content["image_url"] as! String)!
//        let data = try? Data(contentsOf: url)
//        if let imageData = data {
//            let image = UIImage(data: imageData)
//            cell?.resultImageView.image = image
//        }
//        return cell!
//    }
//
//}
class ResultTableView : UITableView, UITableViewDelegate, UITableViewDataSource {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
        self.delegate = self
        self.dataSource = self
    }
    
    override func didMoveToSuperview() {
        self.register(UITableViewCell.self, forCellReuseIdentifier: "ResultDisplayPrototypeCell")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resultArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ResultDisplayPrototypeCell", for: indexPath) as! ResultDisplayCell
        let content = resultArray[indexPath.row]
        cell.titleForName.text = content["name"] as? String
        cell.titleForCategory.text = content["category"] as? String
        let url = URL(string: content["image_url"] as! String)!
        let data = try? Data(contentsOf: url)
        if let imageData = data {
            let image = UIImage(data: imageData)
            cell.resultImageView.image = image
        }
        return cell
    }
}


class SearchViewController: UIViewController, UISearchBarDelegate {



    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var sortBySegmentedControl: UISegmentedControl!
    @IBOutlet weak var opennowButton: UIButton!
    @IBOutlet weak var price1: UIButton!
    @IBOutlet weak var price2: UIButton!
    @IBOutlet weak var price3: UIButton!
    var yelpAPIClient = CDYelpAPIClient(apiKey: "Eyyj7cp9X622nkhFQvhJiJRP_h26M-JANYmm87SIWYsr-uKJG8hDxsxGKksxTE3s0GZW209md3OhFQ372NbV4ERuq-C1THUSys_9TipBBLERLWybn59t2Ggt00UqXXYx")
    
    var term = String()
    var sortBy = CDYelpBusinessSortType.bestMatch
    var openNow = false
    var priceTiers = [CDYelpPriceTier]()

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        searchBar.text = SyncedData.input
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func price1Clicked(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            priceTiers.append(CDYelpPriceTier.oneDollarSign)
        }
        else {
            if let index = priceTiers.firstIndex(of: CDYelpPriceTier.oneDollarSign) {
                priceTiers.remove(at: index)
            }
        }
    }
    
    @IBAction func price2Clicked(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            priceTiers.append(CDYelpPriceTier.twoDollarSigns)
        }
        else {
            if let index = priceTiers.firstIndex(of: CDYelpPriceTier.twoDollarSigns) {
                priceTiers.remove(at: index)
            }
        }
        
    }
    
    @IBAction func price3Clicked(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            priceTiers.append(CDYelpPriceTier.threeDollarSigns)
        }
        else {
            if let index = priceTiers.firstIndex(of: CDYelpPriceTier.threeDollarSigns) {
                priceTiers.remove(at: index)
            }
        }
    }

    @IBAction func openNowClicked(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        openNow = !openNow
    }
    
    @IBAction func sortBySelected(_ sender: UISegmentedControl) {
        let title = sender.titleForSegment(at: (sender.selectedSegmentIndex))!
        switch title {
        case "Best Match":
            sortBy = CDYelpBusinessSortType.bestMatch
        case "Rating":
            sortBy = CDYelpBusinessSortType.rating
        default :
            print ("what")
        }
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        SyncedData.input = self.searchBar.text!
        term = self.searchBar.text!
        let location = SyncedData.location
        yelpAPIClient.searchBusinesses(byTerm: term, location: nil, latitude: location.coordinate.latitude, longitude: location.coordinate.longitude, radius: nil, categories: nil, locale: nil, limit: nil, offset: nil, sortBy: sortBy, priceTiers: priceTiers, openNow: openNow, openAt: nil, attributes: nil) { (response) in
            if response != nil {
                let businesses = response?.businesses
                if businesses!.count > 0 {
                    for item in businesses! {
                        var infoDictionary = [String: Any]()
                        infoDictionary["name"] = item.name
                        infoDictionary["catergory"] = item.categories
                        infoDictionary["rating"] = item.rating
                        infoDictionary["image_url"] = item.imageUrl?.absoluteString
                        resultArray.append(infoDictionary)
                    }
                }
            }
        }
        var table = ResultTableView(coder: NSObject)
        table.reloadData(ResultTableView)
        
        
        
    }

    
    @IBAction func backToMap(_ sender: UIButton) {
        performSegue(withIdentifier: "backToMap", sender: nil)
    }
}


