//
//  TableView.swift
//  
//
//  Created by 姚逸飞 on 7/17/19.
//

import UIKit

class TableView: UITableView {
    @IBOutlet weak var tableView: UITableView!

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
