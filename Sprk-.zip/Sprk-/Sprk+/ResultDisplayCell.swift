//
//  ResultDisplayCell.swift
//  Sprk+
//
//  Created by 姚逸飞 on 7/17/19.
//  Copyright © 2019 Carlo Saraniti. All rights reserved.
//

import UIKit

class ResultDisplayCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
