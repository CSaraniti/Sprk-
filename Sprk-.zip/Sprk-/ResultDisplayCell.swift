//
//  ResultDisplayCell.swift
//  Sprk+
//
//  Created by 姚逸飞 on 7/18/19.
//  Copyright © 2019 Carlo Saraniti. All rights reserved.
//

import UIKit

class ResultDisplayCell: UITableViewCell {

    @IBOutlet weak var titleForName: UILabel!
    @IBOutlet weak var titleForCategory: UILabel!
    @IBOutlet weak var star1: UIImageView!
    @IBOutlet weak var star2: UIImageView!
    @IBOutlet weak var star3: UIImageView!
    @IBOutlet weak var star4: UIImageView!
    @IBOutlet weak var star5: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var resultImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    
    //    func numberOfSections(in tableView: UITableView) -> Int {
    //        return 1
    //    }
    //
    //    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    //        return resultArray.count
    //    }
    //
    //    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    //        let cell = tableView.dequeueReusableCell(withIdentifier: "ResultDisplayPrototypeCell", for: indexPath) as? ResultDisplayCell
    //        let content = resultArray[indexPath.row]
    //        cell?.titleForName.text = content["name"] as! String
    //        cell?.titleForCategory.text = content["category"] as! String
    //        let url = URL(string: content["image_url"] as! String)!
    //        let data = try? Data(contentsOf: url)
    //        if let imageData = data {
    //            let image = UIImage(data: imageData)
    //            cell?.resultImageView.image = image
    //        }
    //        return cell!
    
    //    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    //        return 0 // your number of cells here
    //    }
    //
    //    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
    //        // cell selected code here
    //    }
    //
    //    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    //        let cell = tableView.dequeueReusableCell(withIdentifier: "resultDisplayCell", for: indexPath) as! ResultDisplayCell
    //        let content = resultArray[indexPath.row]
    //        cell.titleForName.text = content["name"] as! String
    //        cell.titleForCategory.text = content["category"] as! String
    //        let url = URL(string: content["image_url"] as! String)!
    //        let data = try? Data(contentsOf: url)
    //        if let imageData = data {
    //            let image = UIImage(data: imageData)
    //            cell.resultImageView?.image = image
    //        }
    //        return cell
    //    }
}
